import streamlit as st
from utils.chat_engine import get_response
from utils.feedback_handler import save_feedback

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
if prompt := st.chat_input("Ask about YabaTech..."):
    # Add user message to history
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Generate response
    response = get_response(prompt)
    
    # Display assistant response
    with st.chat_message("assistant"):
        st.markdown(response)
    
    # Add to history
    st.session_state.messages.append({"role": "assistant", "content": response})

# Feedback buttons
if st.session_state.messages:
    col1, col2 = st.columns(2)
    with col1:
        if st.button("👍 Helpful", use_container_width=True):
            save_feedback(1, st.session_state.messages[-2]["content"], response)
    with col2:
        if st.button("👎 Needs Improvement", use_container_width=True):
            save_feedback(0, st.session_state.messages[-2]["content"], response)