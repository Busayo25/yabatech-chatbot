import streamlit as st

st.title("ℹ️ About This Project")

st.markdown("""
    ### YabaTech Student Assistant Chatbot
    
    **Version**: 1.0  
    **Last Updated**: 2024-01-20
    
    ### Features
    - Answers questions about YabaTech departments
    - Provides admission requirements
    - Gives course information
    - Collects feedback to improve responses
    
    ### Technologies Used
    - Python + Streamlit (Frontend)
    - Transformers (NLP)
    - Plotly (Visualizations)
    
    ### For Developers
    ```bash
    git clone https://github.com/yourrepo/yabatech-chatbot.git
    pip install -r requirements.txt
    streamlit run app.py
    ```
""")

with st.expander("View Knowledge Base Structure"):
    st.json(open("data/knowledge_base.json").read())