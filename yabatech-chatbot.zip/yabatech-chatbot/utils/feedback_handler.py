import json
import os
from datetime import datetime
from pathlib import Path

FEEDBACK_FILE = Path("data/feedback.json")

def initialize_feedback_file():
    """Ensure feedback file exists"""
    FEEDBACK_FILE.parent.mkdir(exist_ok=True)
    if not FEEDBACK_FILE.exists():
        with open(FEEDBACK_FILE, 'w') as f:
            json.dump({"feedbacks": [], "stats": {"positive": 0, "negative": 0}}, f)

def save_feedback(rating: int, question: str, response: str):
    """Save feedback to JSON file"""
    try:
        with open(FEEDBACK_FILE, 'r') as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {"feedbacks": [], "stats": {"positive": 0, "negative": 0}}
    
    # Add new feedback
    feedback_entry = {
        "timestamp": datetime.now().isoformat(),
        "question": question,
        "response": response,
        "rating": rating
    }
    data["feedbacks"].append(feedback_entry)
    
    # Update stats
    if rating == 1:
        data["stats"]["positive"] += 1
    else:
        data["stats"]["negative"] += 1
    
    # Save back to file
    with open(FEEDBACK_FILE, 'w') as f:
        json.dump(data, f, indent=2)