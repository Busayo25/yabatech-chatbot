import random
import json
from typing import Dict, Any

with open('data/knowledge_base.json') as f:
    KNOWLEDGE = json.load(f)

def get_response(user_input: str) -> str:
    user_input = user_input.lower()
    
    # 1. Check greetings
    if any(greet.lower() in user_input for greet in KNOWLEDGE["greetings"]["patterns"]):
        return random.choice(KNOWLEDGE["greetings"]["responses"])
    
    # 2. Check capabilities
    if any(pattern.lower() in user_input for pattern in KNOWLEDGE["capabilities"]["patterns"]):
        return random.choice(KNOWLEDGE["capabilities"]["responses"])
    
    # 3. Check departments/courses
    for dept in KNOWLEDGE["departments"]:
        # Department match
        if dept["name"].lower() in user_input:
            return _format_department_response(dept)
        # Course match
        for course in dept["courses"]:
            if course["name"].lower() in user_input:
                return _format_course_response(course)
    
    # 4. Check admissions
    if any(trigger in user_input for trigger in ["admission", "apply", "requirement"]):
        return random.choice(KNOWLEDGE["admissions"]["responses"])
    
    # 5. Check academics (timetable/results)
    if "timetable" in user_input or "schedule" in user_input:
        return KNOWLEDGE["academics"]["timetable"]["info"]
    if "result" in user_input or "grade" in user_input:
        return random.choice(KNOWLEDGE["academics"]["results"]["responses"])
    
    # 6. Check financial
    if any(fin_word in user_input for fin_word in ["fee", "payment", "school fee"]):
        return random.choice(KNOWLEDGE["financial"]["fees"]["responses"])
    
    # 7. Check goodbye
    if any(bye_word in user_input for bye_word in KNOWLEDGE["goodbye"]["patterns"]):
        return random.choice(KNOWLEDGE["goodbye"]["responses"])
    
    # Fallback
    return ("I can help with:\n"
            "- Departments & Courses\n"
            "- Admissions\n"
            "- Academic Calendar\n"
            "- Financial Information\n\n"
            "Please ask a specific question!")

def _format_department_response(dept: Dict[str, Any]) -> str:
    courses = "\n".join([f"  - {course['name']}" for course in dept["courses"]])
    return (f"**{dept['name']}**\n\n"
            f"📚 Offered Courses:\n{courses}\n\n"
            f"ℹ️ Contact the department office for details")

def _format_course_response(course: Dict[str, Any]) -> str:
    return (f"**{course['name']}**\n\n"
            f"📝 Description: {course['description']}\n"
            f"✅ Requirements: {course['requirements']}\n"
            f"⏳ Duration: {course['duration']}\n\n"
            f"🔗 More info at your department office")